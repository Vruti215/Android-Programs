package com.example.explicitintent;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    Button btnLogin,btnReg;
    EditText Username,Password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnLogin=findViewById(R.id.btnLogin);
        btnReg=findViewById(R.id.btnReg);
        Username=findViewById(R.id.Username);
        Password=findViewById(R.id.Password);

        btnLogin.setOnClickListener(v ->{
            String user = Username.getText().toString();
            String pass = Password.getText().toString();

            if(user.equals("mehul"))
            {
            Intent data= new Intent(MainActivity.this,Dashboard.class);
            data.putExtra("user",user);
            data.putExtra("pass",pass);
            startActivity(data);
            }
            else
            {
                Toast.makeText(this, "Worng Username", Toast.LENGTH_SHORT).show();
            }
        } );

    }
}