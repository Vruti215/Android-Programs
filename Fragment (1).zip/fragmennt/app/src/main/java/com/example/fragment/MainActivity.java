    package com.example.fragment;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

    public class MainActivity extends AppCompatActivity {

    Button b_home,b_About;
    Fragment fragmnet;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b_home = findViewById(R.id.btn_home);
        b_About = findViewById(R.id.btn_About);

        b_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               fragmnet = new one();
               FragmentManager fm = getSupportFragmentManager();
                FragmentTransaction ft = fm.beginTransaction();
                ft.replace(R.id.Fragment1,fragmnet).commit();



            }
        });

        b_About.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragmnet = new two();
                FragmentManager fm = getSupportFragmentManager();
                FragmentTransaction ft = fm.beginTransaction();
                ft.replace(R.id.Fragment1,fragmnet).commit();



            }
        });

    }
}